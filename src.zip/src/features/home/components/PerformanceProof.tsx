"use client";

import {
  formatLivePercent,
  formatLiveRoi,
  formatLiveTimestamp,
  hasLiveStatsData,
} from "@/lib/live-stats";
import { useLiveStats } from "@/lib/use-live-stats";

function ProofSkeletonCard() {
  return (
    <div className="app-card animate-pulse p-4 md:p-5">
      <div className="h-3 w-28 rounded-full bg-[color-mix(in_srgb,var(--pmu-text-muted)_16%,transparent)]" />
      <div className="mt-4 h-9 w-24 rounded-full bg-[color-mix(in_srgb,var(--pmu-text-muted)_18%,transparent)]" />
      <div className="mt-3 h-2 w-full rounded-full bg-[color-mix(in_srgb,var(--pmu-text-muted)_12%,transparent)]" />
      <div className="mt-2.5 h-3 w-28 rounded-full bg-[color-mix(in_srgb,var(--pmu-text-muted)_14%,transparent)]" />
    </div>
  );
}

function ProgressBar({ value }: { value: number }) {
  const clamped = Math.max(0, Math.min(100, value));

  return (
    <div className="mt-3 h-2 overflow-hidden rounded-full bg-[color-mix(in_srgb,var(--pmu-surface-2)_78%,transparent)]">
      <div
        className="h-full rounded-full transition-[width] duration-700 ease-out"
        style={{
          width: `${clamped}%`,
          background: "var(--pmu-primary)",
        }}
      />
    </div>
  );
}

function ProofCard({
  label,
  value,
  description,
  tone = "default",
  progress,
}: {
  label: string;
  value: string;
  description: string;
  tone?: "default" | "positive" | "negative";
  progress?: number;
}) {
  const valueClass =
    tone === "positive"
      ? "text-[var(--pmu-primary)]"
      : tone === "negative"
        ? "text-[var(--pmu-red)]"
        : "text-[var(--pmu-text)]";

  return (
    <div className="app-card p-4 md:p-5">
      <p className="app-label">{label}</p>
      <p
        className={`mt-3 font-mono text-3xl font-black tracking-tight ${valueClass}`}
      >
        {value}
      </p>
      {typeof progress === "number" ? <ProgressBar value={progress} /> : null}
      <p className="mt-2.5 text-sm leading-6 text-[var(--pmu-text-soft)]">
        {description}
      </p>
    </div>
  );
}

function CollectingCard({
  label,
  description,
}: {
  label: string;
  description: string;
}) {
  return (
    <div className="app-card p-4 md:p-5">
      <p className="app-label">{label}</p>
      <p className="mt-3 text-base font-black tracking-tight text-[var(--pmu-text)]">
        Données en cours de collecte
      </p>
      <p className="mt-2.5 text-sm leading-6 text-[var(--pmu-text-soft)]">
        {description}
      </p>
    </div>
  );
}

export function PerformanceProof() {
  const { data, isLoading, isRefreshing } = useLiveStats();
  const hasData = hasLiveStatsData(data);
  const lastUpdated = formatLiveTimestamp(data.lastUpdated);
  const roiTone = data.roi30d >= 0 ? "positive" : "negative";

  return (
    <section className="grid gap-4">
      <div className="flex flex-col gap-2.5 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="app-kicker">Preuve de performance</p>
          <h2 className="mt-2 text-xl font-black tracking-tight text-[var(--pmu-text)] md:text-2xl">
            Des résultats publiés, gains et pertes inclus
          </h2>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-[var(--pmu-text-soft)]">
            Les chiffres ci-dessous sont recalculés automatiquement à partir de
            nos pronostics validés des 30 derniers jours.
          </p>
        </div>

        <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[var(--pmu-text-muted)]">
          {lastUpdated
            ? `Mis à jour ${lastUpdated}`
            : isRefreshing
              ? "Mise à jour..."
              : "Actualisation auto"}
        </p>
      </div>

      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        {isLoading ? (
          <>
            <ProofSkeletonCard />
            <ProofSkeletonCard />
            <ProofSkeletonCard />
            <ProofSkeletonCard />
          </>
        ) : hasData ? (
          <>
            <ProofCard
              label="Taux de réussite"
              value={formatLivePercent(data.winRate, 0)}
              progress={data.winRate}
              tone="positive"
              description="Sur 30 jours"
            />
            <ProofCard
              label="ROI"
              value={formatLiveRoi(data.roi30d)}
              tone={roiTone}
              description="Retour sur investissement"
            />
            <ProofCard
              label="Série en cours"
              value={`${data.currentStreak}${data.currentStreak >= 3 ? " 🔥" : ""}`}
              tone={data.currentStreak >= 3 ? "positive" : "default"}
              description="Placés consécutifs"
            />
            <ProofCard
              label="Pronos validés"
              value={`${data.totalPredictions}`}
              tone="default"
              description="Ce mois"
            />
          </>
        ) : (
          <>
            <CollectingCard label="Taux de réussite" description="Sur 30 jours" />
            <CollectingCard label="ROI" description="Retour sur investissement" />
            <CollectingCard label="Série en cours" description="Placés consécutifs" />
            <CollectingCard label="Pronos validés" description="Ce mois" />
          </>
        )}
      </div>

      <div className="app-card-muted px-4 py-3 text-sm leading-6 text-[var(--pmu-text-soft)] md:px-5">
        Ces statistiques sont calculées automatiquement à partir de nos
        résultats réels. Nous publions nos gains ET nos pertes.
      </div>
    </section>
  );
}
